// src/golden.rs
//
// v0.5.5 — Golden test upgrade (CI hardening)
//
// Golden directory layout:
// tests/golden/<name>.nex
// tests/golden/<name>.nex.stdout
// tests/golden/<name>.nex.events.bin
// tests/golden/<name>.nex.events.jsonl
//
// We verify byte-for-byte equality of binary and jsonl outputs.
// This intentionally makes any change to log schema / ordering / hashing fail CI,
// forcing explicit regeneration via --save-golden.

use std::fs;
use std::io;
use std::path::{Path, PathBuf};

#[derive(Debug)]
pub struct GoldenPaths {
    pub golden_dir: PathBuf,
    pub test_nex: PathBuf,
    pub stdout: PathBuf,
    pub events_bin: PathBuf,
    pub events_jsonl: PathBuf,
}

pub fn golden_paths_for(test_nex_path: &Path) -> io::Result<GoldenPaths> {
    let test_nex = test_nex_path.to_path_buf();
    let name = test_nex_path
        .file_name()
        .and_then(|s| s.to_str())
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "bad test filename"))?;

    // Expect <name>.nex
    if !name.ends_with(".nex") {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "verify-golden expects a .nex file",
        ));
    }

    let golden_dir = PathBuf::from("tests").join("golden");
    let stdout = golden_dir.join(format!("{name}.stdout"));
    let events_bin = golden_dir.join(format!("{name}.events.bin"));
    let events_jsonl = golden_dir.join(format!("{name}.events.jsonl"));

    Ok(GoldenPaths {
        golden_dir,
        test_nex,
        stdout,
        events_bin,
        events_jsonl,
    })
}

pub fn save_golden_artifacts(
    test_nex_path: &Path,
    run_out_dir: &Path,
    captured_stdout: &str,
) -> io::Result<GoldenPaths> {
    let gp = golden_paths_for(test_nex_path)?;
    fs::create_dir_all(&gp.golden_dir)?;

    // Copy .nex into tests/golden if not already (canonical location for CI).
    let dest_nex = gp.golden_dir.join(
        test_nex_path
            .file_name()
            .expect("file name exists for test"),
    );
    fs::copy(test_nex_path, &dest_nex)?;

    // Save stdout
    fs::write(&gp.stdout, captured_stdout.as_bytes())?;

    // Copy events
    let src_bin = run_out_dir.join("run.events.bin");
    let src_jsonl = run_out_dir.join("run.events.jsonl");

    if !src_bin.exists() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            format!("missing run.events.bin in {}", run_out_dir.display()),
        ));
    }
    if !src_jsonl.exists() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            format!("missing run.events.jsonl in {}", run_out_dir.display()),
        ));
    }

    fs::copy(src_bin, &gp.events_bin)?;
    fs::copy(src_jsonl, &gp.events_jsonl)?;

    Ok(gp)
}

pub fn verify_golden_artifacts(
    test_nex_path: &Path,
    run_out_dir: &Path,
    captured_stdout: &str,
) -> io::Result<()> {
    let gp = golden_paths_for(test_nex_path)?;

    // Ensure golden artifacts exist
    for p in [&gp.stdout, &gp.events_bin, &gp.events_jsonl] {
        if !p.exists() {
            return Err(io::Error::new(
                io::ErrorKind::NotFound,
                format!(
                    "missing golden artifact: {} (run: nex run <test>.nex --save-golden)",
                    p.display()
                ),
            ));
        }
    }

    // stdout must match
    let golden_stdout = fs::read_to_string(&gp.stdout)?;
    if golden_stdout != captured_stdout {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "stdout mismatch vs golden (run with --save-golden to update)",
        ));
    }

    // binary log must match byte-for-byte
    let fresh_bin = run_out_dir.join("run.events.bin");
    let fresh_jsonl = run_out_dir.join("run.events.jsonl");

    byte_eq_or_err(&gp.events_bin, &fresh_bin, "events.bin")?;
    byte_eq_or_err(&gp.events_jsonl, &fresh_jsonl, "events.jsonl")?;

    Ok(())
}

fn byte_eq_or_err(golden: &Path, fresh: &Path, label: &str) -> io::Result<()> {
    let a = fs::read(golden)?;
    let b = fs::read(fresh)?;
    if a != b {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("{label} mismatch vs golden (run with --save-golden to update)"),
        ));
    }
    Ok(())
}
