// src/replay.rs
//
// v0.5.7.x — ReplayHarness (binary-only canonical) + Capability Audit counters
// + Path B Structural Verifier Phase 1 (Lifecycle closure + join sanity)
//
// Integrity invariant:
// - Recompute SHA-256 over canonical byte stream:
//     hash(LogHeader.raw + all record bytes EXCEPT RunFinished)
// - Compare computed == RunFinished.run_hash_excluding_finish
//
// Structural Phase 1 invariants (deterministic, single pass):
// - Every TaskStarted has exactly one terminal (Finished OR Cancelled)
// - No started tasks remain open at RunFinished
// - Join only after joined task is terminal
// - Minimal structured join: if joined has known parent, joiner must be that parent
// - Exactly one RunFinished, and it must be the final record

use crate::runtime::event_reader::{
    EventReader, KIND_CAPABILITY_INVOKED, KIND_RESOURCE_VIOLATION, KIND_RUN_FINISHED,
    KIND_TASK_CANCELLED, KIND_TASK_FINISHED, KIND_TASK_JOINED, KIND_TASK_SPAWNED, KIND_TASK_STARTED,
    RECORD_HEADER_LEN,
};
use sha2::{Digest, Sha256};
use std::fs::File;
use std::io::{self, BufReader};
use std::path::Path;

/// Must match src/runtime/audit_jsonl.rs
pub const VIOL_CAPABILITY_DENIED: u32 = 3;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum TerminalKind {
    Finished,
    Cancelled,
}

#[derive(Debug, Default)]
struct TaskState {
    parent: Option<u64>,
    started: bool,
    terminal: Option<TerminalKind>,
}

#[derive(Debug)]
pub struct ReplayResult {
    pub events_seen: u64,
    pub run_finished_seq: u64,
    pub exit_code: i32,
    pub run_hash_hex: String,
    pub codegen_hash_hex: String,
    pub source_hash_hex: String,

    pub cap_allowed_total: u64,
    pub cap_denied_total: u64,
}

fn err_invalid(msg: impl Into<String>) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, msg.into())
}

pub fn verify_log<P: AsRef<Path>>(path: P) -> io::Result<ReplayResult> {
    let path = path.as_ref();
    let f = File::open(path)
        .map_err(|e| io::Error::new(e.kind(), format!("open {:?}: {}", path, e)))?;
    let mut reader = EventReader::new(BufReader::new(f));

    let header = reader.read_log_header()?;

    // Canonical hash stream begins with raw header bytes exactly as read.
    let mut hasher = Sha256::new();
    hasher.update(&header.raw);

    let mut expected_run_hash: Option<[u8; 32]> = None;
    let mut exit_code: Option<i32> = None;
    let mut run_finished_seq: Option<u64> = None;

    let mut events_seen: u64 = 0;
    let mut cap_allowed_total: u64 = 0;
    let mut cap_denied_total: u64 = 0;

    // Structural verifier state.
    let mut tasks: std::collections::BTreeMap<u64, TaskState> = std::collections::BTreeMap::new();
    let mut seen_run_finished = false;

    while let Some(ev) = reader.read_next()? {
        if seen_run_finished {
            return Err(err_invalid(format!(
                "Event after RunFinished: seq={} task={} kind={}",
                ev.seq, ev.task_id, ev.kind
            )));
        }

        events_seen = events_seen.saturating_add(1);

        // Governance counters.
        if ev.kind == KIND_CAPABILITY_INVOKED {
            cap_allowed_total = cap_allowed_total.saturating_add(1);
        } else if ev.kind == KIND_RESOURCE_VIOLATION {
            // payload: [u32 violation_code][u8;32 digest]
            if ev.payload.len() >= 4 {
                let code = u32::from_le_bytes([
                    ev.payload[0],
                    ev.payload[1],
                    ev.payload[2],
                    ev.payload[3],
                ]);
                if code == VIOL_CAPABILITY_DENIED {
                    cap_denied_total = cap_denied_total.saturating_add(1);
                }
            }
        }

        // --- Structural lifecycle accounting (Phase 1) ---
        match ev.kind {
            KIND_TASK_SPAWNED => {
                // payload: [parent u64][child u64]
                if ev.payload.len() != 16 {
                    return Err(err_invalid(format!(
                        "Bad TaskSpawned payload len {} at seq={} task={}",
                        ev.payload.len(),
                        ev.seq,
                        ev.task_id
                    )));
                }
                let parent = u64::from_le_bytes(ev.payload[0..8].try_into().unwrap());
                let child = u64::from_le_bytes(ev.payload[8..16].try_into().unwrap());

                if parent == child {
                    return Err(err_invalid(format!(
                        "TaskSpawned parent==child ({}) at seq={}",
                        parent, ev.seq
                    )));
                }

                // Ensure parent exists in table (may start later, but must be referenced).
                tasks.entry(parent).or_default();

                let e = tasks.entry(child).or_default();
                if let Some(p0) = e.parent {
                    if p0 != parent {
                        return Err(err_invalid(format!(
                            "Task {} has two parents: {} and {} (seq={})",
                            child, p0, parent, ev.seq
                        )));
                    }
                } else {
                    e.parent = Some(parent);
                }
            }

            KIND_TASK_STARTED => {
                // payload length is 0 (enforced here for strictness)
                if !ev.payload.is_empty() {
                    return Err(err_invalid(format!(
                        "Bad TaskStarted payload len {} at seq={} task={}",
                        ev.payload.len(),
                        ev.seq,
                        ev.task_id
                    )));
                }

                let e = tasks.entry(ev.task_id).or_default();
                if e.started {
                    return Err(err_invalid(format!(
                        "Task {} started twice (seq={})",
                        ev.task_id, ev.seq
                    )));
                }
                e.started = true;
            }

            KIND_TASK_FINISHED => {
                // payload: [exit_code i32]
                if ev.payload.len() != 4 {
                    return Err(err_invalid(format!(
                        "Bad TaskFinished payload len {} at seq={} task={}",
                        ev.payload.len(),
                        ev.seq,
                        ev.task_id
                    )));
                }

                let e = tasks.entry(ev.task_id).or_default();
                if !e.started {
                    return Err(err_invalid(format!(
                        "Task {} finished without start (seq={})",
                        ev.task_id, ev.seq
                    )));
                }
                if e.terminal.is_some() {
                    return Err(err_invalid(format!(
                        "Task {} has multiple terminal events (seq={})",
                        ev.task_id, ev.seq
                    )));
                }
                e.terminal = Some(TerminalKind::Finished);
            }

            KIND_TASK_CANCELLED => {
                // payload: [reason_code u32]
                if ev.payload.len() != 4 {
                    return Err(err_invalid(format!(
                        "Bad TaskCancelled payload len {} at seq={} task={}",
                        ev.payload.len(),
                        ev.seq,
                        ev.task_id
                    )));
                }

                let e = tasks.entry(ev.task_id).or_default();
                if !e.started {
                    return Err(err_invalid(format!(
                        "Task {} cancelled without start (seq={})",
                        ev.task_id, ev.seq
                    )));
                }
                if e.terminal.is_some() {
                    return Err(err_invalid(format!(
                        "Task {} has multiple terminal events (seq={})",
                        ev.task_id, ev.seq
                    )));
                }
                e.terminal = Some(TerminalKind::Cancelled);
            }

            KIND_TASK_JOINED => {
                // payload: [joined_task u64]
                if ev.payload.len() != 8 {
                    return Err(err_invalid(format!(
                        "Bad TaskJoined payload len {} at seq={} joiner_task={}",
                        ev.payload.len(),
                        ev.seq,
                        ev.task_id
                    )));
                }
                let joined = u64::from_le_bytes(ev.payload[0..8].try_into().unwrap());

                // Joiner must be started.
                let joiner = tasks.entry(ev.task_id).or_default();
                if !joiner.started {
                    return Err(err_invalid(format!(
                        "Task {} joined before start (seq={})",
                        ev.task_id, ev.seq
                    )));
                }

                // Joined must be terminal before join.
                let joined_state = tasks.entry(joined).or_default();
                if joined_state.terminal.is_none() {
                    return Err(err_invalid(format!(
                        "Task {} joined task {} before it terminated (seq={})",
                        ev.task_id, joined, ev.seq
                    )));
                }

                // Minimal structured join discipline (Phase 1):
                // if joined parent is known, joiner must be that parent.
                if let Some(p) = joined_state.parent {
                    if p != ev.task_id {
                        return Err(err_invalid(format!(
                            "Task {} joined task {} but is not its parent (parent={}) (seq={})",
                            ev.task_id, joined, p, ev.seq
                        )));
                    }
                }
            }

            _ => {}
        }

        // Rebuild canonical record bytes for hashing:
        // [seq u64][task_id u64][kind u16][payload_len u32] + payload
        let payload_len = ev.payload.len() as u32;
        let mut rec = Vec::with_capacity(RECORD_HEADER_LEN + ev.payload.len());
        rec.extend_from_slice(&ev.seq.to_le_bytes());
        rec.extend_from_slice(&ev.task_id.to_le_bytes());
        rec.extend_from_slice(&ev.kind.to_le_bytes());
        rec.extend_from_slice(&payload_len.to_le_bytes());
        rec.extend_from_slice(&ev.payload);

        if ev.kind == KIND_RUN_FINISHED {
            if seen_run_finished {
                return Err(err_invalid(format!("Duplicate RunFinished at seq={}", ev.seq)));
            }
            seen_run_finished = true;

            // RunFinished payload: [exit_code i32][run_hash_excluding_finish 32]
            if ev.payload.len() < 4 + 32 {
                return Err(err_invalid("RunFinished payload too short"));
            }

            let ec = i32::from_le_bytes([ev.payload[0], ev.payload[1], ev.payload[2], ev.payload[3]]);
            let mut rh = [0u8; 32];
            rh.copy_from_slice(&ev.payload[4..36]);

            exit_code = Some(ec);
            expected_run_hash = Some(rh);
            run_finished_seq = Some(ev.seq);

            // IMPORTANT: RunFinished record is excluded from the streaming hash.
            continue;
        }

        // Hash everything except RunFinished.
        hasher.update(&rec);
    }

    if !seen_run_finished {
        return Err(err_invalid("missing RunFinished record"));
    }

    // --- Structural Verifier Phase 1: lifecycle closure at RunFinished ---
    // Root must exist and be closed.
    match tasks.get(&0) {
        Some(root) => {
            if !root.started {
                return Err(err_invalid("Root task (0) never started"));
            }
            if root.terminal.is_none() {
                return Err(err_invalid("Root task (0) not terminated at RunFinished"));
            }
        }
        None => return Err(err_invalid("No task table entry for root (0)")),
    }

    // Every started task must have exactly one terminal event.
    for (tid, st) in tasks.iter() {
        if st.started && st.terminal.is_none() {
            return Err(err_invalid(format!(
                "Orphan task at RunFinished: task {} started but not terminated",
                tid
            )));
        }
        if st.terminal.is_some() && !st.started {
            return Err(err_invalid(format!("Task {} terminated without start", tid)));
        }
    }

    let computed = hasher.finalize();
    let mut computed_arr = [0u8; 32];
    computed_arr.copy_from_slice(&computed[..]);

    let expected = expected_run_hash.ok_or_else(|| err_invalid("missing RunFinished record"))?;
    if computed_arr != expected {
        return Err(err_invalid(format!(
            "run hash mismatch: expected {}, computed {}",
            hex::encode(expected),
            hex::encode(computed_arr)
        )));
    }

    Ok(ReplayResult {
        events_seen,
        run_finished_seq: run_finished_seq.unwrap_or(0),
        exit_code: exit_code.unwrap_or(1),
        run_hash_hex: hex::encode(computed_arr),
        codegen_hash_hex: hex::encode(header.codegen_hash),
        source_hash_hex: hex::encode(header.source_hash),
        cap_allowed_total,
        cap_denied_total,
    })
}

